/**
 * Test Importer for MyTestStudent Web
 * Supports parsing native JSON, TXT test banks (#, +, - format), CSV spreadsheets,
 * and binary .MTF test files.
 */

/**
 * Validates and normalizes raw JSON test object against the standard schema.
 * @param {Object} rawData
 * @returns {Object} Clean validated test object
 */
export function parseJSONTest(rawData) {
  if (!rawData || typeof rawData !== 'object') {
    throw new Error('Yaroqsiz JSON formati!');
  }

  const questions = Array.isArray(rawData.questions) ? rawData.questions : [];
  if (questions.length === 0) {
    throw new Error('Test faylida savollar topilmadi!');
  }

  const cleanQuestions = questions.map((q, idx) => {
    const id = q.id || `q_${idx + 1}`;
    const type = q.type || 'single';
    const weight = typeof q.weight === 'number' && q.weight > 0 ? q.weight : 1;
    const text = String(q.text || `Savol #${idx + 1}`).trim();

    return {
      ...q,
      id,
      type,
      weight,
      text,
      explanation: q.explanation || null
    };
  });

  return {
    version: rawData.version || '1.0',
    meta: {
      title: rawData.meta?.title || 'Yangi Test',
      description: rawData.meta?.description || '',
      author: rawData.meta?.author || '',
      createdAt: rawData.meta?.createdAt || new Date().toISOString().split('T')[0],
      totalQuestionsInFile: cleanQuestions.length
    },
    settings: {
      timeLimitMinutes: rawData.settings?.timeLimitMinutes ?? 30,
      timeLimitPerQuestion: rawData.settings?.timeLimitPerQuestion ?? 0,
      questionsToSelect: rawData.settings?.questionsToSelect ?? 0,
      randomizeQuestions: rawData.settings?.randomizeQuestions ?? true,
      randomizeAnswers: rawData.settings?.randomizeAnswers ?? true,
      allowPrevious: rawData.settings?.allowPrevious ?? true,
      immediateFeedback: rawData.settings?.immediateFeedback ?? false,
      showResultsAtEnd: rawData.settings?.showResultsAtEnd ?? true,
      allowReview: rawData.settings?.allowReview ?? true,
      passingScorePercent: rawData.settings?.passingScorePercent ?? 55,
      gradingScale: rawData.settings?.gradingScale || {
        type: '5-point',
        cutoffs: { '5': 86, '4': 71, '3': 55, '2': 0 }
      }
    },
    questions: cleanQuestions
  };
}

/**
 * Parses popular text-based test banks using the standard '#' (question),
 * '+' (correct answer), and '-' (incorrect answer) notation.
 * Automatically classifies questions as 'single' (1 correct) or 'multiple' (>1 correct).
 * @param {string} textContent
 * @param {string} title
 * @returns {Object}
 */
export function parseTXTTest(textContent, title = 'Matnli Test Banki') {
  if (!textContent || typeof textContent !== 'string') {
    throw new Error('Matnli fayl bo\'sh yoki noto\'g\'ri!');
  }

  const lines = textContent.split(/\r?\n/);
  const questions = [];
  let currentQ = null;

  for (let rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;

    if (line.startsWith('#')) {
      // Save previously accumulated question
      if (currentQ && currentQ.answers.length > 0) {
        finalizeQuestion(currentQ, questions);
      }

      currentQ = {
        id: `q_${questions.length + 1}`,
        text: line.substring(1).trim(),
        answers: []
      };
    } else if (line.startsWith('+') || line.startsWith('-')) {
      if (!currentQ) {
        currentQ = {
          id: `q_${questions.length + 1}`,
          text: 'Savol matni',
          answers: []
        };
      }

      const isCorrect = line.startsWith('+');
      const optText = line.substring(1).trim();
      if (optText) {
        currentQ.answers.push({
          id: `a_${currentQ.answers.length + 1}`,
          text: optText,
          correct: isCorrect
        });
      }
    }
  }

  // Push final question
  if (currentQ && currentQ.answers.length > 0) {
    finalizeQuestion(currentQ, questions);
  }

  if (questions.length === 0) {
    throw new Error('TXT faylida "#" bilan boshlanuvchi savollar topilmadi. Har bir savol # bilan, to\'g\'ri javob + bilan, noto\'g\'ri javob esa - bilan boshlanishi kerak.');
  }

  const defaultSelectCount = questions.length > 50 ? 50 : 0;
  const defaultTime = questions.length > 50 ? 50 : 30;

  return parseJSONTest({
    meta: {
      title: title.replace(/\.[^/.]+$/, ''),
      description: `Matnli (.txt) formatdan yuklangan test to'plami (${questions.length} ta savol)`,
      author: 'O\'qituvchi',
      totalQuestionsInFile: questions.length
    },
    settings: {
      questionsToSelect: defaultSelectCount,
      timeLimitMinutes: defaultTime,
      randomizeQuestions: true,
      randomizeAnswers: true,
      allowPrevious: true,
      immediateFeedback: false,
      showResultsAtEnd: true,
      allowReview: true,
      passingScorePercent: 55
    },
    questions
  });
}

function finalizeQuestion(currentQ, questions) {
  const correctAnswers = currentQ.answers.filter(a => a.correct);
  const correctCount = correctAnswers.length;

  if (correctCount === 0 && currentQ.answers.length > 0) {
    // If no answer was marked with +, mark the first as correct by default
    currentQ.answers[0].correct = true;
    currentQ.type = 'single';
    currentQ.weight = 1;
  } else if (correctCount > 1) {
    currentQ.type = 'multiple';
    currentQ.scoring = 'partial_with_penalty';
    currentQ.weight = correctCount;
  } else {
    currentQ.type = 'single';
    currentQ.weight = 1;
  }

  questions.push(currentQ);
}

/**
 * Parses simple CSV formatted test sheets.
 * Format: Type,Question,Weight,OptionA,OptionB,OptionC,OptionD,CorrectAnswer
 * @param {string} csvText
 * @param {string} title
 * @returns {Object}
 */
export function parseCSVTest(csvText, title = 'CSV Test Bank') {
  const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);
  if (lines.length < 2) {
    throw new Error('CSV fayli yetarli ma\'lumotga ega emas!');
  }

  const questions = [];
  const firstLine = lines[0].toLowerCase();
  const startIndex = (firstLine.includes('type') || firstLine.includes('savol')) ? 1 : 0;

  for (let i = startIndex; i < lines.length; i++) {
    const row = splitCSVLine(lines[i]);
    if (row.length < 3) continue;

    const type = (row[0] || 'single').trim().toLowerCase();
    const text = (row[1] || '').trim();
    const weight = parseFloat(row[2]) || 1;

    if (!text) continue;

    if (type === 'single' || type === 'multiple') {
      const correctMarker = (row[row.length - 1] || '').trim();
      const optionTexts = row.slice(3, row.length - 1).filter(t => t.trim() !== '');

      const answers = optionTexts.map((optText, oIdx) => {
        const letter = String.fromCharCode(65 + oIdx);
        const isCorr = correctMarker.includes(letter) ||
                       correctMarker.includes(String(oIdx + 1)) ||
                       correctMarker.toLowerCase() === optText.trim().toLowerCase();

        return {
          id: `a_${oIdx + 1}`,
          text: optText.trim(),
          correct: isCorr
        };
      });

      questions.push({
        id: `csv_q_${questions.length + 1}`,
        type,
        weight,
        text,
        answers
      });
    }
  }

  if (questions.length === 0) {
    throw new Error('CSV faylidan birorta ham yaroqli savol o\'qib olinmadi.');
  }

  return parseJSONTest({
    meta: { title },
    questions
  });
}

function splitCSVLine(line) {
  const result = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') {
      inQuotes = !inQuotes;
    } else if (c === ',' && !inQuotes) {
      result.push(cur);
      cur = '';
    } else {
      cur += c;
    }
  }
  result.push(cur);
  return result.map(s => s.replace(/^"|"$/g, '').trim());
}

/**
 * Binary MTF Parser for MyTestX test files.
 * If MTF is encrypted / compressed, provides a helpful diagnostic explaining the format issue.
 * @param {ArrayBuffer} buffer
 * @param {string} filename
 * @returns {Object} Parsed test structure
 */
export function parseMTFBinary(buffer, filename = 'MyTest_Import.mtf') {
  const bytes = new Uint8Array(buffer);

  // Check if buffer contains non-printable binary garbage / encryption
  let nullCount = 0;
  let nonAsciiCount = 0;
  for (let i = 0; i < Math.min(bytes.length, 1000); i++) {
    if (bytes[i] === 0) nullCount++;
    if (bytes[i] > 127) nonAsciiCount++;
  }

  // If the file is heavily compressed/encrypted binary:
  let text = '';
  try {
    const decoder1251 = new TextDecoder('windows-1251');
    text = decoder1251.decode(bytes);
  } catch (e) {
    const decoderUtf8 = new TextDecoder('utf-8');
    text = decoderUtf8.decode(bytes);
  }

  // Test if text contains valid '#' or '+' patterns
  if (text.includes('#') && (text.includes('+') || text.includes('-'))) {
    return parseTXTTest(text, filename);
  }

  // If text looks like corrupted binary / compressed stream:
  const isBinaryGarbage = /[\x00-\x08\x0E-\x1F]/.test(text.slice(0, 100)) ||
                          (nonAsciiCount > 400 && !text.includes('Savol') && !text.includes('test'));

  if (isBinaryGarbage) {
    throw new Error(
      'Ushbu .MTF fayl MyTestX dasturining siqilgan/shifrlangan binar formatida ekanligi sababli matnlar buzilib ko\'rinadi. ' +
      'Tavsiya: Testni oddiy .txt formatida (savollar # bilan, to\'g\'ri javob + bilan) yuklang. Bu 100% toza va xatosiz ishlaydi!'
    );
  }

  throw new Error('MTF fayli tuzilmasi aniqlanmadi. Iltimos, faylni .txt yoki .json formatida yuklang.');
}
